Flujo oferta: capa models. Ver CONTRIBUTING.md (sin reglas de negocio en views; datos de otros flujos solo por su API).
